# Deployment

The project is provider-agnostic. A practical production topology is:

- Next.js frontend
- FastAPI API
- Redis
- one or more Celery workers
- PostgreSQL
- Cloudflare R2/S3/Supabase-compatible object storage

Set all `.env` values in the hosting provider's secret/environment settings. Never put `OPENAI_API_KEY` in frontend variables.

For Railway/Render/Fly.io/VPS, create separate services for frontend, API and worker. Worker machines should have FFmpeg and yt-dlp. Attach persistent database/storage services and configure HTTPS/domain routing.

For low-resource hosting, keep `MAX_CONCURRENT_JOBS` small. Heavy FFmpeg processing can exceed a basic web-service CPU/RAM budget, so separate worker capacity is important.
