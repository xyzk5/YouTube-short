# API

- `POST /api/jobs` create background job
- `GET /api/jobs/{job_id}` status
- `POST /api/jobs/{job_id}/cancel` cancel
- `GET /api/jobs/{job_id}/clips` generated clips
- `GET /api/clips/{clip_id}/download` signed media URL
- `GET /api/health` health

FastAPI also exposes OpenAPI/Swagger at `/docs`.
