# Local development

## Backend

Python 3.12+, FFmpeg and yt-dlp are required.

```bash
cd backend
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

Run Redis/PostgreSQL or use Docker Compose. For quick API-only development the default SQLite URL can be used, but Celery still needs Redis.

## Frontend

```bash
cd frontend
npm install
NEXT_PUBLIC_API_URL=http://localhost:8000 npm run dev
```

## Termux

Install Python, Node.js, FFmpeg and yt-dlp through the available Termux packages. Running the full production stack on a phone is for testing only; large FFmpeg jobs should run on a server with sufficient CPU/RAM/storage.
