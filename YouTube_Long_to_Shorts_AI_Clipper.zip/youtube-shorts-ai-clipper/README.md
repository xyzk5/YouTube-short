# YouTube Long-to-Shorts AI Clipper

Production-oriented, mobile-first AI clipping platform based on the supplied developer specification.

## What it does
Paste an authorized YouTube URL, create a background job, download/process the media with `yt-dlp` + FFmpeg, transcribe it, ask an LLM for candidate moments, validate/de-duplicate them, render 9:16 MP4s with captions, and expose the results through a responsive dashboard.

**Rights notice:** Process only videos you are authorized to download, edit and publish and only where platform/API terms permit. Editing/cropping/captions do not automatically make copyrighted material legally safe.

## Stack
- Next.js + React + TypeScript + Tailwind
- FastAPI + Pydantic
- Celery + Redis
- PostgreSQL
- FFmpeg + yt-dlp
- OpenAI transcription + structured clip analysis
- S3-compatible object storage (S3/R2/Supabase-compatible endpoint)
- Docker Compose

## Quick local setup
1. Copy `.env.example` to `.env` and add `OPENAI_API_KEY` plus database/storage values.
2. Install Docker Desktop or Docker Engine.
3. Run `docker compose up --build`.
4. Open `http://localhost:3000`.
5. Paste a YouTube URL you own/have permission to use.

For non-Docker development see `docs/LOCAL_DEVELOPMENT.md`.

## Architecture
Browser -> Next.js -> FastAPI -> Celery/Redis -> worker -> yt-dlp/FFmpeg/OpenAI -> PostgreSQL + object storage.

Long processing never runs inside the normal API request. The API returns a job ID immediately and the frontend polls job status. Exact progress is stage-based unless the worker can safely calculate a percentage.

## Environment
See `.env.example`. Secrets stay server-side.

Important limits include `MAX_VIDEO_DURATION_SECONDS`, `MAX_FILE_SIZE_MB`, `MAX_CLIPS_PER_JOB`, `MAX_CONCURRENT_JOBS`, `JOB_RETENTION_HOURS`, and `RETRY_COUNT`.

## Testing
`pytest -q backend/tests`

Unit tests do not call paid external APIs. `backend/tests/fixtures/test.mp4` is generated as a tiny local fixture by the test helper when needed.

## Production
Use separate API/worker resources when FFmpeg workloads are heavy. Set HTTPS, a real PostgreSQL instance, Redis, and S3/R2-compatible storage. See `docs/DEPLOYMENT.md`.
