from sqlalchemy import String, Text, Integer, Float, DateTime, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from datetime import datetime, timezone
from ..db import Base
class Job(Base):
    __tablename__='jobs'
    id:Mapped[str]=mapped_column(String(36),primary_key=True)
    youtube_url:Mapped[str]=mapped_column(Text)
    source_title:Mapped[str|None]=mapped_column(Text,nullable=True)
    source_duration:Mapped[float|None]=mapped_column(Float,nullable=True)
    status:Mapped[str]=mapped_column(String(20),default='queued')
    progress:Mapped[int|None]=mapped_column(Integer,nullable=True)
    current_stage:Mapped[str]=mapped_column(String(80),default='Preparing job')
    requested_clip_count:Mapped[int]=mapped_column(Integer)
    min_clip_duration:Mapped[int]=mapped_column(Integer)
    max_clip_duration:Mapped[int]=mapped_column(Integer)
    settings_json:Mapped[dict]=mapped_column(JSON,default=dict)
    error_code:Mapped[str|None]=mapped_column(String(80),nullable=True)
    error_message:Mapped[str|None]=mapped_column(Text,nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))
    started_at:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)
    completed_at:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)
    expires_at:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)
    clips:Mapped[list['Clip']]=relationship(back_populates='job',cascade='all, delete-orphan')
class Clip(Base):
    __tablename__='clips'
    id:Mapped[str]=mapped_column(String(36),primary_key=True)
    job_id:Mapped[str]=mapped_column(ForeignKey('jobs.id',ondelete='CASCADE'))
    start_time:Mapped[float]=mapped_column(Float)
    end_time:Mapped[float]=mapped_column(Float)
    duration:Mapped[float]=mapped_column(Float)
    title:Mapped[str]=mapped_column(Text)
    reason:Mapped[str]=mapped_column(Text)
    ai_score:Mapped[float|None]=mapped_column(Float,nullable=True)
    storage_key:Mapped[str]=mapped_column(Text)
    thumbnail_key:Mapped[str|None]=mapped_column(Text,nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))
    expires_at:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)
    job:Mapped[Job]=relationship(back_populates='clips')
