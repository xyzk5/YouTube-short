from pydantic_settings import BaseSettings, SettingsConfigDict
from functools import lru_cache
class Settings(BaseSettings):
    model_config=SettingsConfigDict(env_file='.env', extra='ignore')
    openai_api_key:str=''
    openai_transcription_model:str='gpt-4o-mini-transcribe'
    openai_analysis_model:str='gpt-4o-mini'
    database_url:str='sqlite:///./clipper.db'
    redis_url:str='redis://localhost:6379/0'
    storage_endpoint:str=''
    storage_bucket:str='clips'
    storage_access_key:str=''
    storage_secret_key:str=''
    storage_region:str='us-east-1'
    max_video_duration_seconds:int=3600
    max_file_size_mb:int=2000
    max_clips_per_job:int=10
    max_concurrent_jobs:int=2
    job_retention_hours:int=24
    retry_count:int=2
    cors_origins:str='http://localhost:3000'
@lru_cache
def get_settings(): return Settings()
