import boto3
from botocore.client import Config
from ..config import get_settings

def client():
    s=get_settings(); return boto3.client('s3',endpoint_url=s.storage_endpoint or None,aws_access_key_id=s.storage_access_key or None,aws_secret_access_key=s.storage_secret_key or None,region_name=s.storage_region,config=Config(signature_version='s3v4'))
def ensure_bucket():
    s=get_settings()
    if not s.storage_endpoint: return
    c=client()
    try: c.head_bucket(Bucket=s.storage_bucket)
    except Exception: c.create_bucket(Bucket=s.storage_bucket)
def put(path,key):
    s=get_settings(); c=client(); c.upload_file(str(path),s.storage_bucket,key,ExtraArgs={'ContentType':'video/mp4'})
def signed(key,expires=900):
    s=get_settings(); return client().generate_presigned_url('get_object',Params={'Bucket':s.storage_bucket,'Key':key},ExpiresIn=expires)
