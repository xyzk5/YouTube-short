from pydantic import BaseModel, Field, HttpUrl, field_validator
from typing import Literal
class JobCreate(BaseModel):
    youtube_url: HttpUrl
    clip_count:int=Field(3,ge=1,le=10)
    duration:int|Literal['auto']=Field('auto')
    clip_type:str='auto'
    caption_style:str='bold'
    caption_position:str='bottom'
    aspect_ratio:str='9:16'
    @field_validator('youtube_url')
    @classmethod
    def youtube_only(cls,v):
        u=str(v)
        if 'youtube.com/' not in u and 'youtu.be/' not in u: raise ValueError('Please enter a valid YouTube URL.')
        return v
class JobOut(BaseModel):
    id:str; status:str; progress:int|None; current_stage:str; completed_clips:int; total_clips:int; error_message:str|None=None
class ClipOut(BaseModel):
    id:str; title:str; duration:float; reason:str; ai_score:float|None; download_url:str|None
