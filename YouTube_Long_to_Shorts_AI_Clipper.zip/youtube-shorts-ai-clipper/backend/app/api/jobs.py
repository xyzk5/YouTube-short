import uuid
from fastapi import APIRouter,HTTPException
from sqlalchemy import select
from ..db import SessionLocal
from ..models import Job,Clip
from ..schemas.job import JobCreate
from ..workers.tasks import process_job
from ..storage.s3 import signed
router=APIRouter(prefix='/api')
@router.post('/jobs')
def create_job(body:JobCreate):
    db=SessionLocal(); jid=str(uuid.uuid4()); duration=body.duration
    min_d,max_d=(15,60) if duration=='auto' else (int(duration),int(duration))
    j=Job(id=jid,youtube_url=str(body.youtube_url),status='queued',progress=0,current_stage='Preparing job',requested_clip_count=body.clip_count,min_clip_duration=min_d,max_clip_duration=max_d,settings_json=body.model_dump())
    db.add(j); db.commit(); db.close(); process_job.delay(jid); return {'job_id':jid,'status':'queued'}
@router.get('/jobs/{job_id}')
def status(job_id:str):
    db=SessionLocal(); j=db.get(Job,job_id)
    if not j: raise HTTPException(404,'Job not found')
    return {'id':j.id,'status':j.status,'progress':j.progress,'current_stage':j.current_stage,'completed_clips':len(j.clips),'total_clips':j.requested_clip_count,'error_message':j.error_message}
@router.post('/jobs/{job_id}/cancel')
def cancel(job_id:str):
    db=SessionLocal(); j=db.get(Job,job_id)
    if not j: raise HTTPException(404,'Job not found')
    if j.status in ('completed','failed','cancelled'): return {'status':j.status}
    from ..workers.celery_app import celery_app
    celery_app.control.revoke(job_id,terminate=True); j.status='cancelled'; j.current_stage='Cancelled'; db.commit(); db.close(); return {'status':'cancelled'}
@router.get('/jobs/{job_id}/clips')
def clips(job_id:str):
    db=SessionLocal(); j=db.get(Job,job_id)
    if not j: raise HTTPException(404,'Job not found')
    return [{'id':c.id,'title':c.title,'duration':c.duration,'reason':c.reason,'ai_score':c.ai_score,'download_url':signed(c.storage_key)} for c in j.clips]
@router.get('/clips/{clip_id}/download')
def download_clip(clip_id:str):
    db=SessionLocal(); c=db.get(Clip,clip_id)
    if not c: raise HTTPException(404,'Clip not found')
    return {'url':signed(c.storage_key)}
