from datetime import datetime,timezone
from ..db import SessionLocal
from ..models import Job
from ..storage.s3 import client
from ..config import get_settings

def main():
    db=SessionLocal(); s=get_settings(); now=datetime.now(timezone.utc)
    for j in db.query(Job).filter(Job.expires_at!=None,Job.expires_at<now).all():
        try:
            c=client()
            for clip in j.clips:
                try:c.delete_object(Bucket=s.storage_bucket,Key=clip.storage_key)
                except Exception:pass
        finally: db.delete(j)
    db.commit(); db.close()
if __name__=='__main__': main()
