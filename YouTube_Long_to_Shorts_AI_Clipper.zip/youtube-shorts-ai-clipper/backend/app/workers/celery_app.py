from celery import Celery
from ..config import get_settings
celery_app=Celery('clipper',broker=get_settings().redis_url,backend=get_settings().redis_url)
celery_app.conf.task_acks_late=True
celery_app.conf.worker_prefetch_multiplier=1
celery_app.conf.task_time_limit=7200
