import uuid, shutil, os
from pathlib import Path
from datetime import datetime, timezone, timedelta
from sqlalchemy.orm import Session
from .celery_app import celery_app
from ..db import SessionLocal
from ..models import Job, Clip
from ..config import get_settings
from ..services.media import download,duration,extract_audio,render_clip
from ..services.transcription import transcribe
from ..services.ai import choose_clips
from ..services.captions import make_srt
from ..storage.s3 import put,ensure_bucket

STAGES=['Validating URL','Preparing job','Downloading video','Extracting audio','Generating transcript','Analyzing transcript','Selecting best moments','Validating clips','Rendering clips','Generating captions','Finalizing files','Uploading results','Completed']
def update(db,j,stage,progress=None): j.current_stage=stage; j.progress=progress; db.commit()

def validate_candidates(cands,src_dur,min_dur,max_dur,count):
    out=[]
    for c in sorted(cands,key=lambda x:float(x.get('score',0)),reverse=True):
        try: a=float(c['start']); b=float(c['end']);
        except: continue
        if a<0 or b<=a or b>src_dur or not(min_dur<=b-a<=max_dur): continue
        if any(max(a,x['start']) < min(b,x['end']) for x in out): continue
        out.append({'start':round(a,2),'end':round(b,2),'title':str(c.get('title','Selected moment'))[:200],'reason':str(c.get('reason',''))[:500],'score':float(c.get('score',0))})
        if len(out)>=count: break
    return out

@celery_app.task(bind=True,max_retries=2)
def process_job(self,job_id):
    db:Session=SessionLocal(); j=db.get(Job,job_id); s=get_settings(); work=Path('/tmp/clipper')/job_id; work.mkdir(parents=True,exist_ok=True)
    try:
        j.status='processing'; j.started_at=datetime.now(timezone.utc); db.commit(); update(db,j,STAGES[0],5)
        video,info=download(j.youtube_url,work); j.source_title=info.get('title'); src_dur=duration(video); j.source_duration=src_dur
        if src_dur>s.max_video_duration_seconds: raise ValueError('This video exceeds the maximum allowed duration.')
        if video.stat().st_size>s.max_file_size_mb*1024*1024: raise ValueError('This video exceeds the maximum allowed file size.')
        update(db,j,STAGES[2],15); audio=work/'audio.wav'; extract_audio(video,audio); update(db,j,STAGES[4],30)
        tr=transcribe(audio); update(db,j,STAGES[5],40)
        min_d=15; max_d=60
        if j.max_clip_duration and j.min_clip_duration: min_d=j.min_clip_duration; max_d=j.max_clip_duration
        cands=choose_clips(tr,j.requested_clip_count,min_d,max_d,j.settings_json.get('clip_type','auto')); update(db,j,STAGES[7],55)
        clips=validate_candidates(cands,src_dur,min_d,max_d,j.requested_clip_count)
        if not clips: raise ValueError('No suitable clip moments were found. Try another video or settings.')
        update(db,j,STAGES[8],65); ensure_bucket()
        for i,c in enumerate(clips,1):
            clip_id=str(uuid.uuid4()); out=work/f'{clip_id}.mp4'; srt=work/f'{clip_id}.srt'; make_srt(tr.get('words',[]),c['start'],c['end'],srt); render_clip(video,out,c['start'],c['end'],srt,j.settings_json.get('caption_style','bold'))
            key=f'jobs/{job_id}/{clip_id}.mp4'; put(out,key)
            db.add(Clip(id=clip_id,job_id=job_id,start_time=c['start'],end_time=c['end'],duration=c['end']-c['start'],title=c['title'],reason=c['reason'],ai_score=c['score'],storage_key=key,expires_at=datetime.now(timezone.utc)+timedelta(hours=s.job_retention_hours)))
            db.commit(); update(db,j,STAGES[11],65+int(i/len(clips)*30))
        j.status='completed'; j.progress=100; j.current_stage='Completed'; j.completed_at=datetime.now(timezone.utc); j.expires_at=datetime.now(timezone.utc)+timedelta(hours=s.job_retention_hours); db.commit()
    except Exception as e:
        j.status='failed'; j.error_message=str(e)[:500]; j.error_code='PROCESSING_ERROR'; j.current_stage='Failed'; db.commit()
        raise
    finally:
        shutil.rmtree(work,ignore_errors=True); db.close()
