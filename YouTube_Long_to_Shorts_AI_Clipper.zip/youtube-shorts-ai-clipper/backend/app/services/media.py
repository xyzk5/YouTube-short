import os, subprocess, json, shutil
from pathlib import Path
import yt_dlp

def download(url:str,out:Path):
    out.mkdir(parents=True,exist_ok=True)
    template=str(out/'source.%(ext)s')
    opts={'outtmpl':template,'format':'bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/best','merge_output_format':'mp4','noplaylist':True,'quiet':True,'no_warnings':True}
    with yt_dlp.YoutubeDL(opts) as ydl:
        info=ydl.extract_info(url,download=True)
        path=Path(ydl.prepare_filename(info)).with_suffix('.mp4')
        if not path.exists():
            candidates=list(out.glob('source.*')); path=max(candidates,key=lambda p:p.stat().st_size)
        return path, info

def duration(path:Path)->float:
    p=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','json',str(path)],capture_output=True,text=True,check=True)
    return float(json.loads(p.stdout)['format']['duration'])

def extract_audio(video:Path,audio:Path):
    subprocess.run(['ffmpeg','-y','-i',str(video),'-vn','-ac','1','-ar','16000','-c:a','pcm_s16le',str(audio)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)

def render_clip(src:Path,out:Path,start:float,end:float,caption_file:Path|None=None,style:str='bold'):
    vf="scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920"
    if caption_file: vf += f",subtitles={caption_file.as_posix()}:force_style='FontSize=18,Alignment=2,MarginV=120,Outline=2,BorderStyle=1'"
    cmd=['ffmpeg','-y','-ss',str(start),'-i',str(src),'-t',str(end-start),'-vf',vf,'-c:v','libx264','-preset','veryfast','-crf','23','-c:a','aac','-b:a','128k','-movflags','+faststart',str(out)]
    subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
