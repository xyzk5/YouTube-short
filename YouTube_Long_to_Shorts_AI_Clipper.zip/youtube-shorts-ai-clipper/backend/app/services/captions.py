from pathlib import Path

def make_srt(words:list, start:float, end:float, out:Path):
    selected=[w for w in words if float(w.get('end',0))>=start and float(w.get('start',0))<=end]
    lines=[]; n=1
    for i in range(0,len(selected),5):
        chunk=selected[i:i+5]
        a=max(start,float(chunk[0].get('start',start))); b=min(end,float(chunk[-1].get('end',end)))
        def ts(x):
            ms=int(max(0,x)*1000); h=ms//3600000; ms%=3600000; m=ms//60000; ms%=60000; sec=ms//1000; ms%=1000
            return f'{h:02}:{m:02}:{sec:02},{ms:03}'
        text=' '.join(str(x.get('word','')).replace('-->','') for x in chunk).strip()
        if text: lines += [str(n),f'{ts(a-start)} --> {ts(b-start)}',text,'']; n+=1
    out.write_text('\n'.join(lines),encoding='utf-8')
