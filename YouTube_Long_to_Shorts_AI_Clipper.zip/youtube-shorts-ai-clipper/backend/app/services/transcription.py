from pathlib import Path
from openai import OpenAI
from ..config import get_settings

def transcribe(audio:Path):
    s=get_settings()
    if not s.openai_api_key: raise RuntimeError('OPENAI_API_KEY is not configured.')
    client=OpenAI(api_key=s.openai_api_key)
    with audio.open('rb') as f:
        r=client.audio.transcriptions.create(model=s.openai_transcription_model,file=f,response_format='verbose_json',timestamp_granularities=['segment','word'])
    return {'text':getattr(r,'text',''),'segments':[x.model_dump() if hasattr(x,'model_dump') else dict(x) for x in getattr(r,'segments',[])], 'words':[x.model_dump() if hasattr(x,'model_dump') else dict(x) for x in getattr(r,'words',[])]}
