from urllib.parse import urlparse

def validate_youtube_url(url:str)->bool:
    p=urlparse(url)
    return p.hostname in {'youtube.com','www.youtube.com','m.youtube.com','youtu.be','www.youtu.be'}
