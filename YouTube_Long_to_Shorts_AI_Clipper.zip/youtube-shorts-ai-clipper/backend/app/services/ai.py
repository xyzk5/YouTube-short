import json
from openai import OpenAI
from ..config import get_settings

def choose_clips(transcript:dict,count:int,min_dur:int,max_dur:int,clip_type:str):
    s=get_settings()
    if not s.openai_api_key: raise RuntimeError('OPENAI_API_KEY is not configured.')
    client=OpenAI(api_key=s.openai_api_key)
    # Time windows keep long transcripts within a manageable request size.
    segs=transcript.get('segments',[])
    windows=[]; cur=[]; start=None; chars=0
    for seg in segs:
        if start is None: start=seg['start']
        cur.append(seg); chars += len(seg.get('text',''))
        if chars>9000:
            windows.append(cur); cur=[]; start=None; chars=0
    if cur: windows.append(cur)
    candidates=[]
    for w in windows:
        payload='\n'.join(f"[{x['start']:.2f}-{x['end']:.2f}] {x.get('text','')}" for x in w)
        prompt=f"Select up to {max(count*2,4)} self-contained engaging moments for {clip_type}. Prefer hooks, payoff, useful information, humor, emotion or surprise; avoid silence, incomplete sentences and duplicates. Each duration must be {min_dur}-{max_dur}s. Return JSON only with clips: start,end,title,reason,score. Score is a heuristic 0-1, not viral probability.\nTRANSCRIPT:\n{payload}"
        r=client.responses.create(model=s.openai_analysis_model,input=prompt)
        txt=r.output_text
        try: data=json.loads(txt)
        except Exception: continue
        candidates.extend(data.get('clips',[]))
    return candidates
