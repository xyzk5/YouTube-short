from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .config import get_settings
from .db import Base,engine
from .api.jobs import router
from .models import Job,Clip
s=get_settings(); Base.metadata.create_all(engine)
app=FastAPI(title='YouTube Long-to-Shorts AI Clipper',version='1.0.0')
app.add_middleware(CORSMiddleware,allow_origins=[x.strip() for x in s.cors_origins.split(',')],allow_credentials=True,allow_methods=['*'],allow_headers=['*'])
app.include_router(router)
@app.get('/api/health')
def health(): return {'api':'ok','database':'configured','queue':'configured'}
