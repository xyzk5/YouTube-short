import os
os.environ['DATABASE_URL']='sqlite:///./test.db'
from app.services.url import validate_youtube_url

def test_youtube_url():
    assert validate_youtube_url('https://www.youtube.com/watch?v=x')
    assert validate_youtube_url('https://youtu.be/x')
    assert not validate_youtube_url('https://example.com/x')
