const API=process.env.NEXT_PUBLIC_API_URL||'http://localhost:8000';
export async function createJob(payload:any){const r=await fetch(`${API}/api/jobs`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});if(!r.ok)throw new Error((await r.json()).detail||'Unable to create job');return r.json()}
export async function getJob(id:string){const r=await fetch(`${API}/api/jobs/${id}`,{cache:'no-store'});if(!r.ok)throw new Error('Job unavailable');return r.json()}
export async function getClips(id:string){const r=await fetch(`${API}/api/jobs/${id}/clips`,{cache:'no-store'});if(!r.ok)throw new Error('Clips unavailable');return r.json()}
export async function cancelJob(id:string){await fetch(`${API}/api/jobs/${id}/cancel`,{method:'POST'})}
