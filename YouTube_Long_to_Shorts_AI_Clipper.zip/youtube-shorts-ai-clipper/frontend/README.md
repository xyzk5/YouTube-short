# Frontend

`npm install && npm run dev`

Set `NEXT_PUBLIC_API_URL` to the FastAPI URL.
